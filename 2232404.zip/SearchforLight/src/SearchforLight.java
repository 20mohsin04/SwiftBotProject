// Import necessary libraries
import swiftbot.Button;
import swiftbot.ImageSize;
import swiftbot.SwiftBotAPI;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

// Define the SearchforLight class
public class SearchforLight {
    // Initialize the SwiftBotAPI
    static SwiftBotAPI API = new SwiftBotAPI();
    // Define variables to store the maximum light intensity detected on the left, center, and right
    static int maxLeftIntensity = 0;
    static int maxCenterIntensity = 0;
    static int maxRightIntensity = 0;
    // Define a variable to count the number of times light is detected
    static int lightDetectedCount = 0;
    // Define a list to store the movements made by the Swiftbot
    static List<String> movements = new ArrayList<>();
    // Define a variable to store the total distance moved by the Swiftbot
    static int totalDistance = 0;
    // Define variables to store the start time and the last time light was detected
    static long startTime;
    static long lastLightDetectedTime;
    // Define a boolean variable to indicate whether the program is running
    static boolean isRunning = true;

    // Define the main method
    public static void main(String[] args) {
        // Print a welcome message and instructions to the console
        System.out.println("************************************");
        System.out.println("Welcome to the Swiftbot Light Search Program!");
        System.out.println("This program will guide the Swiftbot to move towards the direction with the highest light intensity.");
        System.out.println("The Swiftbot will have green underlights while searching for the light, and red when it detects an object.");
        System.out.println("You can press 'X' on the Swiftbot to terminate the program at any time.");
        System.out.println("Press 'A' on the Swiftbot to start the program.");
        System.out.println("************************************");
        // Call the starting method to start the program
        starting();
    }

    // Define a method to start the program
    public static void starting() {
        try {
            // Enable the 'A' button to start the program
            API.enableButton(Button.A, () -> {
                System.out.println("A pressed. Starting the program...");
                // Record the start time
                startTime = System.currentTimeMillis();
                // Record the last time light was detected
                lastLightDetectedTime = startTime;
                // Call the Next method to start the light search
                Next();
                // Disable all buttons after the program starts
                API.disableAllButtons();
            });

            // Enable the 'X' button to terminate the program at any time
            API.enableButton(Button.X, () -> {
                System.out.println("X pressed. Terminating program.");
                // Set the isRunning variable to false to stop the program
                isRunning = false;
                // Display the log information
                displayLog();
            });

            // Handle invalid button presses
            API.enableButton(Button.B, () -> {
                System.out.println("Invalid input. Please press 'A' to start the program or 'X' to terminate the program.");
            });
            API.enableButton(Button.Y, () -> {
                System.out.println("Invalid input. Please press 'A' to start the program or 'X' to terminate the program.");
            });
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Method to capture image and decide the direction of movement
    public static void Next() {
        while (isRunning) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // Capture a grayscale image
            BufferedImage img = API.takeGrayscaleStill(ImageSize.SQUARE_480x480);
            System.out.println("Captured a grayscale image.");

            // Calculate brightness of image sections
            int numSections = 3; // Divide the image into 3 sections (left, middle, right)
            int sectionWidth = img.getWidth() / numSections;
            int brightestSectionIndex = -1;
            double maxBrightness = Double.MIN_VALUE;
            for (int i = 0; i < numSections; i++) {
                int startX = i * sectionWidth;
                int endX = (i + 1) * sectionWidth;

                // Calculate average brightness of the section
                double sectionBrightness = calculateAverageBrightness(img, startX, 0, endX, img.getHeight());

                // Update brightest section
                if (sectionBrightness > maxBrightness) {
                    maxBrightness = sectionBrightness;
                    brightestSectionIndex = i;
                }

                // Update max intensities
                if (i == 0 && sectionBrightness > maxLeftIntensity) {
                    maxLeftIntensity = (int) sectionBrightness;
                } else if (i == 1 && sectionBrightness > maxCenterIntensity) {
                    maxCenterIntensity = (int) sectionBrightness;
                } else if (i == 2 && sectionBrightness > maxRightIntensity) {
                    maxRightIntensity = (int) sectionBrightness;
                }
            }

            System.out.println("Calculated brightness of image sections. Brightest section index: " + brightestSectionIndex);

            // Update the time of the last light detection
            if (maxBrightness > 0) {
                lastLightDetectedTime = System.currentTimeMillis();
                lightDetectedCount++;
            }

            // Check if the Swiftbot has not encountered a light source for 5 seconds
            if (System.currentTimeMillis() - lastLightDetectedTime >= 5000) {
                // Change direction 90 degrees to either left or right randomly
                int randomDirection = (int) (Math.random() * 2);
                if (randomDirection == 0) {
                    // Move left
                    API.move(0, 70, 500);
                    movements.add("Left 70 cm");
                    totalDistance += 70;
                } else {
                    // Move right
                    API.move(70, 0, 500);
                    movements.add("Right 70 cm");
                    totalDistance += 70;
                }
                lastLightDetectedTime = System.currentTimeMillis(); // Reset the timer
                System.out.println("No light source detected for 5 seconds. Changed direction randomly.");
            } else {
                // Move SwiftBot in the direction of the brightest section
                if (brightestSectionIndex == 0) {
                    // Move left, then move forward
                    API.move(0, 70, 500);
                    handleObstacleDetection();
                    if (!isRunning) break;  // Add this line
                    movements.add("Left 70 cm");
                    totalDistance += 70;
                    System.out.println("Moved left 70 cm.");
                } else if (brightestSectionIndex == 2) {
                    // Move right, then move forward
                    API.move(70, 0, 500);
                    handleObstacleDetection();
                    if (!isRunning) break;  // Add this line
                    movements.add("Right 70 cm");
                    totalDistance += 70;
                    System.out.println("Moved right 70 cm.");
                } else {
                    // Move forward
                    API.move(100, 100, 1000);
                    handleObstacleDetection();
                    if (!isRunning) break;  // Add this line
                    movements.add("Forward 100 cm");
                    totalDistance += 100;
                    System.out.println("Moved forward 100 cm.");
                }
            }
        }
    }

    // Method to calculate average brightness of a section in the image
    private static double calculateAverageBrightness(BufferedImage img, int startX, int startY, int endX, int endY) {
        double totalBrightness = 0.0;
        int numPixels = 0;

        for (int y = startY; y < endY; y++) {
            for (int x = startX; x < endX; x++) {
                int pixel = img.getRGB(x, y);
                int brightness = (pixel >> 16) & 0xFF; // Extract brightness (grayscale value)
                totalBrightness += brightness;
                numPixels++;
            }
        }

        return totalBrightness / numPixels;
    }

    // Method to handle obstacle detection
    private static void handleObstacleDetection() {
        if (API.useUltrasound() <= 10) { // Reduced the threshold to 10 cm for testing
            // Object detected
            System.out.println("Object detected in front!");
            API.fillUnderlights(new int[]{255, 0, 0}); // Red underlights
            System.out.println("Blinking underlights in red.");
            System.out.println("Please remove the object.");

            // Blink underlights in red for 5 seconds
            for (int i = 0; i < 5; i++) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                API.fillUnderlights(new int[]{255, 0, 0}); // Red underlights
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                API.fillUnderlights(new int[]{0, 0, 0}); // Turn off underlights
            }

            if (API.useUltrasound() > 10) {
                // Object removed
                System.out.println("Object removed. Resuming search.");
                API.fillUnderlights(new int[]{0, 255, 0}); // Green underlights
            } else {
                // Object not removed
                System.out.println("Object not removed. Terminating program.");

                // Ask the user if they want to view the log
                System.out.println("Press 'Y' if you want to view the log, or 'X' to exit");
                CountDownLatch latch = new CountDownLatch(1);
                API.disableButton(Button.Y);
                API.disableButton(Button.X);
                API.enableButton(Button.Y, () -> {
                    displayLog();
                    isRunning = false;
                    API.fillUnderlights(new int[]{0, 0, 0}); // Turn off underlights
                    latch.countDown();  // Release the latch
                });
                API.enableButton(Button.X, () -> {
                    System.out.println("Exiting the program without displaying the log.");
                    isRunning = false;
                    API.fillUnderlights(new int[]{0, 0, 0}); // Turn off underlights
                    latch.countDown();  // Release the latch
                });

                try {
                    latch.await();  // Wait here until the latch is released
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        } else {
            // No object detected
            API.fillUnderlights(new int[]{0, 255, 0}); // Green underlights
        }
    }

    // Method to display log information
    private static void displayLog() {
        System.out.println("Log Information:");
        System.out.println("Overall highest average intensity observed in each section:");
        System.out.println("   Left: " + maxLeftIntensity);
        System.out.println("   Center: " + maxCenterIntensity);
        System.out.println("   Right: " + maxRightIntensity);
        System.out.println("Number of times the Swiftbot detected light: " + lightDetectedCount);
        System.out.println("Movements of the Swiftbot:");
        for (String movement : movements) {
            System.out.println("   " + movement);
        }
        System.out.println("Total distance traveled: " + totalDistance + " cm");
        long duration = (System.currentTimeMillis() - startTime) / 1000; // Duration in seconds
        System.out.println("Duration of the execution: " + duration + " seconds");
    }
}